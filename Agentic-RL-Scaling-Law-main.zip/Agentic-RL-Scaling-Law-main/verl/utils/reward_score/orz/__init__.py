"""
Adapted from https://github.com/Open-Reasoner-Zero/Open-Reasoner-Zero
"""
