# Verilog

版本： Icarus Verilog 13.0

目前通过 https://github.com/NVlabs/verilog-eval 的 evaluate_functional_correctness 指令执行。
