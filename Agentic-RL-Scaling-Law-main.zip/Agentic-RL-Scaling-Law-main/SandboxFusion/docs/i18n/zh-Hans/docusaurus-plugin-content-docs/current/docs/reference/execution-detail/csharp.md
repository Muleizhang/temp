# CSharp

版本： dotnet-sdk-8.0

沙盒会先执行 `dotnet new console -o <tmp_dir>` 创建一个项目，并将传入的 code 写入 `Program.cs` 文件。

之后执行 `dotnet run --project <tmp_dir>` 运行代码。
