# Scala

Version: 2.11.12

The sandbox will try to find the Scala class name in the submitted code. If not found, it will return an error. The submitted code will be written to a random file.

Compilation command: `scalac <filename>`, execution command: `scala <classname>`.
