# CSharp

Version: dotnet-sdk-8.0

The sandbox will first execute `dotnet new console -o <tmp_dir>` to create a project, and write the input code to the `Program.cs` file.

Then it executes `dotnet run --project <tmp_dir>` to run the code.
