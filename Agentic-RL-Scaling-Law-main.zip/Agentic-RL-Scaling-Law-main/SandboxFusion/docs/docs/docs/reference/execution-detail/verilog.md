# Verilog

Version: Icarus Verilog 13.0

Currently executed through the evaluate_functional_correctness command from https://github.com/NVlabs/verilog-eval
